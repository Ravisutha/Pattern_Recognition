This folder contains:
1. rsakrep-classified-takehome1.txt : Output file
2. rsakrep-takehome1.pdf			: Takehome1 documentation
3. Test2.m							: Driver script to classify test data
4. calculate_class.m				: Classifier function
5. mean_covariance.m				: Function to calculate mean and covariance
6. File_reading.m					: Function to read train data
7. File_reading2.m					: Function to read test data
8. readme.txt						: This file

Pledge:
On my honor I have neither given nor received aid on this
exam.
